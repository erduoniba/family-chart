import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen,
  Calendar,
  Clock,
  Crown,
  Flag,
  Home,
  MapPin,
  ScrollText,
  Sword,
  User,
  X,
  Menu,
} from 'lucide-react';

const MingDynastyEmperors = () => {
  const [activeSection, setActiveSection] = useState('overview');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // 滚动监听
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['ancestors', 'emperors', 'southern-ming'];
      
      for (const section of sections) {
        const element = document.getElementById(section);
        if (!element) continue;

        const rect = element.getBoundingClientRect();
        if (rect.top <= 100 && rect.bottom >= 100) {
          setActiveSection(section);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // 平滑滚动
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(sectionId);
      setIsMobileMenuOpen(false);
    }
  };

  // 追尊先祖数据
  const ancestorsData = [
    { id: 1, templeName: '明德祖', posthumousName: '玄皇帝', name: '朱百六', note: '明太祖追尊' },
    { id: 2, templeName: '明懿祖', posthumousName: '恒皇帝', name: '朱四九', note: '明太祖追尊' },
    { id: 3, templeName: '明熙祖', posthumousName: '裕皇帝', name: '朱初一', note: '明太祖追尊' },
    { id: 4, templeName: '明仁祖', posthumousName: '淳皇帝', name: '朱世珍', note: '明太祖之父，明太祖追尊' },
    { id: 5, templeName: '明兴宗', posthumousName: '孝康皇帝', name: '朱标', note: '明惠宗追尊，靖难之役后被明成祖废除，后明安宗追复' },
    { id: 6, templeName: '明睿宗', posthumousName: '文献皇帝', name: '朱祐杬', note: '明世宗追尊' },
  ];

  // 明朝皇帝数据
  const emperorsData = [
    {
      id: 1,
      name: '朱元璋',
      templeName: '太祖',
      fullTitle: '开天行道肇纪立极大圣至神仁文义武俊德成功高皇帝',
      birthDeath: '1328年 - 1398年',
      reign: '1368年 - 1398年',
      description: '出身贫寒，曾为地主放牛、做过和尚。元末加入郭子兴的红巾军，因战功被封吴王。1368年称帝，国号大明，定都南京。在位期间整肃吏治、严惩贪腐，加强皇权，设立锦衣卫，推行多项制度改革，如三司六部制、卫所制度等。同时兴"文字狱"，定八股取士。洪武三十一年在南京逝世，葬于南京钟山孝陵。',
      image: 'https://s.coze.cn/t/a3iEawKiZXs/'
    },
    // 其他皇帝数据...
  ];

  // 南明皇帝数据
  const southernMingData = [
    {
      id: 1,
      name: '朱由崧',
      templeName: '安宗',
      fullTitle: '处天承道诚敬英哲缵文备武宣仁度孝简皇帝',
      birthDeath: '1607年 - 1646年',
      reign: '1644年 - 1645年',
      description: '福王朱常洵之子，崇祯帝自缢后在南京被拥立为帝，年号弘光。在位期间沉湎酒色，政治腐败，不久被清军俘虏处死。',
      image: 'https://s.coze.cn/t/-l7frATOlgo/'
    },
    // 其他南明皇帝数据...
  ];

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans">
      {/* 导航条 */}
      <nav className="sticky top-0 z-50 bg-blue-900 text-white shadow-lg">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Crown className="h-6 w-6" />
            <h1 className="text-xl font-bold">明朝帝王研究</h1>
          </div>
          
          {/* 桌面导航 */}
          <div className="hidden md:flex space-x-6">
            {[
              { id: 'ancestors', label: '追尊先祖', icon: <User className="h-5 w-5" /> },
              { id: 'emperors', label: '明朝皇帝', icon: <Crown className="h-5 w-5" /> },
              { id: 'southern-ming', label: '南明皇帝', icon: <Flag className="h-5 w-5" /> },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`flex items-center space-x-1 px-3 py-2 rounded-md transition-colors ${
                  activeSection === item.id ? 'bg-blue-700' : 'hover:bg-blue-800'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </div>
          
          {/* 移动端菜单按钮 */}
          <button
            className="md:hidden p-2 rounded-md hover:bg-blue-800 transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        
        {/* 移动端菜单 */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="md:hidden bg-blue-800 overflow-hidden"
            >
              <div className="flex flex-col space-y-2 p-4">
                {[
                  { id: 'ancestors', label: '追尊先祖', icon: <User className="h-5 w-5" /> },
                  { id: 'emperors', label: '明朝皇帝', icon: <Crown className="h-5 w-5" /> },
                  { id: 'southern-ming', label: '南明皇帝', icon: <Flag className="h-5 w-5" /> },
                ].map((item) => (
                  <motion.button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    whileHover={{ x: 5 }}
                    className={`flex items-center space-x-2 px-4 py-3 rounded-md ${
                      activeSection === item.id ? 'bg-blue-700' : 'hover:bg-blue-700'
                    }`}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* 主要内容 */}
      <main className="container mx-auto px-4 py-8">
        {/* 简介部分 */}
        <section className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="bg-white rounded-xl shadow-md p-6 md:p-8"
          >
            <h2 className="text-3xl font-bold mb-4 flex items-center">
              <BookOpen className="mr-3 text-blue-600" />
              明朝帝王研究
            </h2>
            <p className="text-lg mb-6">
              明朝（1368年 - 1644年）是中国历史上最后一个由汉族建立的大一统中原王朝，共传十二世，历经十六帝，享国276年。
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <motion.div 
                whileHover={{ y: -5 }}
                className="bg-blue-50 rounded-lg p-4 flex items-center"
              >
                <Crown className="h-8 w-8 text-blue-600 mr-3" />
                <div>
                  <div className="text-sm text-blue-800">皇帝数量</div>
                  <div className="text-2xl font-bold text-blue-900">16位</div>
                </div>
              </motion.div>
              
              <motion.div 
                whileHover={{ y: -5 }}
                className="bg-green-50 rounded-lg p-4 flex items-center"
              >
                <Clock className="h-8 w-8 text-green-600 mr-3" />
                <div>
                  <div className="text-sm text-green-800">享国时间</div>
                  <div className="text-2xl font-bold text-green-900">276年</div>
                </div>
              </motion.div>
              
              <motion.div 
                whileHover={{ y: -5 }}
                className="bg-purple-50 rounded-lg p-4 flex items-center"
              >
                <Calendar className="h-8 w-8 text-purple-600 mr-3" />
                <div>
                  <div className="text-sm text-purple-800">时间跨度</div>
                  <div className="text-2xl font-bold text-purple-900">1368-1644</div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </section>

        {/* 追尊先祖部分 */}
        <section id="ancestors" className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-white rounded-xl shadow-md p-6 md:p-8"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <User className="mr-3 text-blue-600" />
              一、追尊先祖
            </h2>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">序号</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">庙号</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">谥号</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">名讳</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">备注</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {ancestorsData?.map((ancestor) => (
                    <tr key={ancestor?.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{ancestor?.id}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{ancestor?.templeName}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{ancestor?.posthumousName}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{ancestor?.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{ancestor?.note}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        </section>

        {/* 明朝皇帝部分 */}
        <section id="emperors" className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-white rounded-xl shadow-md p-6 md:p-8"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Crown className="mr-3 text-blue-600" />
              二、明朝皇帝（1368年 - 1644年）
            </h2>
            
            {emperorsData?.map((emperor, index) => (
              <motion.div
                key={emperor?.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="mb-12 last:mb-0"
              >
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="w-full md:w-1/3">
                    <motion.div whileHover={{ scale: 1.02 }} className="rounded-lg overflow-hidden shadow-md">
                      <img 
                        src={emperor?.image} 
                        alt={`明朝皇帝${emperor?.name}肖像`}
                        className="w-full h-auto object-cover"
                        width={512}
                        height={512}
                      />
                    </motion.div>
                  </div>
                  
                  <div className="w-full md:w-2/3">
                    <h3 className="text-xl font-bold mb-2">
                      {index + 1}. 明{emperor?.templeName}{emperor?.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-4">{emperor?.fullTitle}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="flex items-start">
                        <Calendar className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                        <div>
                          <div className="text-sm text-gray-500">生卒</div>
                          <div className="font-medium">{emperor?.birthDeath}</div>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <Clock className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                        <div>
                          <div className="text-sm text-gray-500">在位时间</div>
                          <div className="font-medium">{emperor?.reign}</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-semibold mb-2 flex items-center">
                        <ScrollText className="h-4 w-4 text-blue-600 mr-2" />
                        简介
                      </h4>
                      <p className="text-gray-700">{emperor?.description}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* 南明皇帝部分 */}
        <section id="southern-ming">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-white rounded-xl shadow-md p-6 md:p-8"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Flag className="mr-3 text-blue-600" />
              三、南明皇帝
            </h2>
            
            {southernMingData?.map((emperor, index) => (
              <motion.div
                key={emperor?.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="mb-12 last:mb-0"
              >
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="w-full md:w-1/3">
                    <motion.div whileHover={{ scale: 1.02 }} className="rounded-lg overflow-hidden shadow-md">
                      <img 
                        src={emperor?.image} 
                        alt={`南明皇帝${emperor?.name}肖像`}
                        className="w-full h-auto object-cover"
                        width={512}
                        height={512}
                      />
                    </motion.div>
                  </div>
                  
                  <div className="w-full md:w-2/3">
                    <h3 className="text-xl font-bold mb-2">
                      {index + 1}. 明{emperor?.templeName}{emperor?.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-4">{emperor?.fullTitle}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="flex items-start">
                        <Calendar className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                        <div>
                          <div className="text-sm text-gray-500">生卒</div>
                          <div className="font-medium">{emperor?.birthDeath}</div>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <Clock className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                        <div>
                          <div className="text-sm text-gray-500">在位时间</div>
                          <div className="font-medium">{emperor?.reign}</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-semibold mb-2 flex items-center">
                        <ScrollText className="h-4 w-4 text-blue-600 mr-2" />
                        简介
                      </h4>
                      <p className="text-gray-700">{emperor?.description}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </section>
      </main>

      {/* 页脚 */}
      <footer className="bg-blue-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="mb-4">
            <a 
              href="https://space.coze.cn" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-300 hover:text-white underline transition-colors"
            >
              created by coze space
            </a>
          </div>
          <div className="text-sm text-blue-300">
            页面内容均由 AI 生成，仅供参考
          </div>
        </div>
      </footer>
    </div>
  );
};

export default MingDynastyEmperors;